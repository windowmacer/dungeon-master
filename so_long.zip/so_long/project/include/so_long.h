/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/17 22:59:03 by kirill            #+#    #+#             */
/*   Updated: 2022/06/02 11:21:12 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H
# define BUFF_SIZE 1

# include <stdio.h>
# include <unistd.h>
# include <errno.h>
# include <stdlib.h>
# include <fcntl.h>
# include "../mlx/mlx.h"

typedef struct s_game
{
	int		map_height;
	int		map_length;
	int		player_position_x;
	int		player_position_y;
	int		pos_x;
	int		pos_y;
	int		game_score;
	int		max_score;
	char	*stepping;
	char	**map_data;
	int		game_over;
	int		steps;
	void	*end_img;
	void	*wall;
	void	*exit;
	void	*play;
	void	*player;
	void	*floor;
	void	*doom;
	void	*items;
	void	*p2;
	void	*p3;
	void	*r3;
	void	*r2;
	void	*rplay;
	int		pos;
	int		flag;
	void	*mlx;
	void	*win;
}	t_game;

typedef struct s_gnl
{
	char			*stl;
	char			*str;
	int				f;
	ssize_t			gg;
}	t_gnl;

size_t	ft_strlen(const char *str);
void	ft_err(char *s);
char	*ft_strjoin(char const *s1, char const *s2);
char	*ft_strchr(const char *str, int ch);
char	*ft_strndup(char *s1, size_t n);
char	*ft_freejoin(char	*s1, char	*s2);
char	*get_next_line(int fd);
int		so_long(t_game *s);
char	*ft_itoa(int n);
void	ft_free_textures(t_game *map);
void	ft_init_type(t_game *s, int fd);
void	ft_null_type(t_game *s);
void	ft_count(t_game *game, int fd);
void	ft_null_str(t_game *game, int fd);
void	ft_textures(t_game *m);
void	ft_image_to_win(t_game *map, char t, int x, int y);
void	ft_rendering(t_game *map);
int		left_right(t_game *s, int a);
int		up_down(t_game *s, int a);
int		ft_finish(t_game *map);
int		open_file(char *filename);
int		ft_check_type(char *name);
int		ft_arr(char *line, t_game *s);
int		ft_check_rect(char *line, int i, t_game *s);
void	ft_completion_data(char *line, int i, t_game *s);
void	ft_filling(char *filename, t_game *s);
void	ft_invalid(t_game *s);
int		update(t_game *mlx);
int		ft_antagonist_init(t_game *s);
int		ft_game_over(t_game *map);
int		standing_right(t_game *s);
int		anti_up_down(t_game *s, int a);

#endif
