/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 13:23:53 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/31 18:15:35 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	up_down(t_game *s, int a)
{
	if (s->map_data[s->player_position_x + a][s->player_position_y] == '1')
		return (0);
	if (s->map_data[s->player_position_x + a][s->player_position_y] == 'C')
		s->game_score++;
	if (s->map_data[s->player_position_x + a][s->player_position_y] == 'R')
		return (ft_game_over(s));
	if (s->map_data[s->player_position_x + a][s->player_position_y] == 'E' \
	&& s->game_score < s->max_score)
		return (0);
	if (s->map_data[s->player_position_x + a][s->player_position_y] == 'E' \
	&& s->game_score == s->max_score)
		return (ft_finish(s));
	s->map_data[s->player_position_x][s->player_position_y] = '0';
	s->map_data[s->player_position_x + a][s->player_position_y] = 'P';
	ft_rendering(s);
	s->player_position_x = s->player_position_x + a;
	return (0);
}

int	left_right(t_game *s, int a)
{
	if (s->map_data[s->player_position_x][s->player_position_y + a] == '1')
		return (0);
	if (s->map_data[s->player_position_x][s->player_position_y + a] == 'C')
		s->game_score++;
	if (s->map_data[s->player_position_x][s->player_position_y + a] == 'R')
		return (ft_game_over(s));
	if (s->map_data[s->player_position_x][s->player_position_y + a] == 'E' \
	&& s->game_score < s->max_score)
		return (0);
	if (s->map_data[s->player_position_x][s->player_position_y + a] == 'E' \
	&& s->game_score == s->max_score)
		return (ft_finish(s));
	s->map_data[s->player_position_x][s->player_position_y] = '0';
	s->map_data[s->player_position_x][s->player_position_y + a] = 'P';
	s->player_position_y = s->player_position_y + a;
	ft_rendering(s);
	return (0);
}

int	key_hook(int keycode, t_game *map)
{
	if (keycode == 53)
	{
		mlx_destroy_window(map->mlx, map->win);
		ft_free_textures(map);
		write(2, "Goodbye!\n", 9);
		exit(0);
	}
	if (keycode == 1)
		return (up_down(map, 1));
	if (keycode == 13)
		return (up_down(map, -1));
	if (keycode == 2)
		return (left_right(map, 1));
	if (keycode == 0)
		return (left_right(map, -1));
	return (0);
}

int	exit_hook(int keycode, t_game *map)
{
	(void) keycode;
	(void) map;
	write(2, "Goodbye!\n", 9);
	exit(0);
}

int	so_long(t_game *s)
{
	s->mlx = mlx_init();
	s->win = mlx_new_window(s->mlx, (s->map_length * 100), \
	(s->map_height * 100), "so_long");
	ft_textures(s);
	ft_antagonist_init(s);
	ft_rendering(s);
	mlx_hook(s->win, 2, 0, key_hook, s);
	mlx_hook(s->win, 17, 0, exit_hook, s);
	mlx_loop_hook(s->mlx, standing_right, s);
	mlx_loop(s->mlx);
	return (0);
}
