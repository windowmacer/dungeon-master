/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bonus_textures.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 17:07:24 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/31 19:10:51 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	ft_game_over(t_game *map)
{
	write(2, "You died!\n", 10);
	ft_free_textures(map);
	exit(1);
	return (1);
}

int	ft_antagonist_init(t_game *s)
{
	int		i;
	int		j;
	char	**line;

	i = s->map_height - 1;
	j = s->map_length - 1;
	line = s->map_data;
	while (line[i])
	{
		while (line[i][j])
		{
			if (line[i][j] == '0')
			{
				line[i][j] = 'R';
				s->pos_x = i;
				s->pos_y = j;
				return (1);
			}
			j--;
		}
		j = s->map_length - 1;
		i--;
	}
	return (0);
}

int	anti_up_down(t_game *s, int a)
{
	if (s->map_data[s->pos_x + a][s->pos_y] == '1')
		return (-1 * s->pos);
	if (s->map_data[s->pos_x + a][s->pos_y] == 'P')
		return (-1 * ft_game_over(s));
	if (s->map_data[s->pos_x + a][s->pos_y] == 'C')
		return (-1 * s->pos);
	if (s->map_data[s->pos_x + a][s->pos_y] == 'E')
		return (-1 * s->pos);
	s->map_data[s->pos_x][s->pos_y] = '0';
	s->map_data[s->pos_x + a][s->pos_y] = 'R';
	s->pos_x = s->pos_x + a;
	return (s->pos);
}

static void	util(t_game *s, int *i)
{
	if (*i == 0)
	{
		s->play = s->player;
		s->rplay = s->doom;
	}
	if (*i == 1)
	{
		s->play = s->p2;
		s->rplay = s->r3;
		s->rplay = s->r2;
	}
	if (*i == 2)
	{
		s->play = s->p3;
		s->rplay = s->r3;
	}
	if (*i == 3)
	{
		s->play = s->p2;
		s->rplay = s->r3;
		s->rplay = s->r2;
	}
}

int	standing_right(t_game *s)
{
	static int	i;
	static int	j;

	if (i == 4)
	{
		i = 0;
		j = 0;
	}
	if (j == 10)
	{
		i++;
		j = 0;
	}
	util(s, &i);
	mlx_put_image_to_window(s->mlx, s->win, s->play, \
	s->player_position_y * 100, s->player_position_x * 100);
	mlx_put_image_to_window(s->mlx, s->win, s->rplay, \
	s->pos_y * 100, s->pos_x * 100);
	j++;
	return (0);
}
