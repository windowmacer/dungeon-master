/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/26 17:23:40 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/28 13:07:23 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	*ft_calloc(size_t num, size_t size)
{
	size_t	a;
	char	*p;

	a = 0;
	p = (char *)malloc(num * size);
	if (p == NULL)
		return (NULL);
	while (a < num * size)
	{
		p[a] = 0;
		a++;
	}
	return ((void *)p);
}

static char	*plus(int n)
{
	int		a;
	int		i;
	char	*s;

	a = n;
	i = 0;
	while (a >= 1)
	{
		a = a / 10;
		i++;
	}
	s = (char *)ft_calloc(i + 1, 1);
	if (!s)
		return (NULL);
	i--;
	while (n >= 1)
	{
		s[i] = (n % 10) + 48;
		n /= 10;
		i--;
	}
	return (s);
}

static char	*minus(long n)
{
	long	a;
	int		i;
	char	*s;

	a = n;
	i = 1;
	while (a >= 1)
	{
		a = a / 10;
		i++;
	}
	s = (char *)ft_calloc(i + 1, 1);
	if (!s)
		return (NULL);
	s[0] = '-';
	i--;
	while (n > 0)
	{
		s[i] = (n % 10) + 48;
		n /= 10;
		i--;
	}
	return (s);
}

char	*ft_itoa(int n)
{
	char	*s;

	if (n == 0)
	{
		s = (char *)malloc((sizeof(char) * 2));
		s[0] = '0';
		s[1] = '\0';
		return (s);
	}
	if (n > 0)
		s = plus(n);
	else
		s = minus(-(long)n);
	if (!s)
		return (NULL);
	return (s);
}
