/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   textures.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 13:44:01 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/31 19:10:20 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_textures(t_game *m)
{
	int	p[2];

	m->wall = mlx_xpm_file_to_image(m->mlx, "./images/1.xpm", &p[0], &p[1]);
	m->exit = mlx_xpm_file_to_image(m->mlx, "./images/E.xpm", &p[0], &p[1]);
	m->player = mlx_xpm_file_to_image(m->mlx, "./images/1P.xpm", &p[0], &p[1]);
	m->floor = mlx_xpm_file_to_image(m->mlx, "./images/0.xpm", &p[0], &p[1]);
	m->items = mlx_xpm_file_to_image(m->mlx, "./images/C.xpm", &p[0], &p[1]);
	m->doom = mlx_xpm_file_to_image(m->mlx, "./images/1R.xpm", &p[0], &p[1]);
	m->p2 = mlx_xpm_file_to_image(m->mlx, "./images/2P.xpm", &p[0], &p[1]);
	m->p3 = mlx_xpm_file_to_image(m->mlx, "./images/3P.xpm", &p[0], &p[1]);
	m->r2 = mlx_xpm_file_to_image(m->mlx, "./images/2R.xpm", &p[0], &p[1]);
	m->r3 = mlx_xpm_file_to_image(m->mlx, "./images/3R.xpm", &p[0], &p[1]);
}

void	ft_image_to_win(t_game *map, char t, int x, int y)
{
	x *= 100;
	y *= 100;
	if (t == 'P')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->player, x, y);
	if (t == '1')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->wall, x, y);
	if (t == 'C')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->items, x, y);
	if (t == 'E')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->exit, x, y);
	if (t == '0')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->floor, x, y);
	if (t == 'R')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->doom, x, y);
}

void	ft_free_textures(t_game *map)
{
	int		i;
	char	**str;

	i = 0;
	str = map->map_data;
	while (i < map->map_height)
	{
		free(str[i]);
		i++;
	}
	free(str);
}

void	ft_rendering(t_game *map)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	map->pos = anti_up_down(map, map->pos);
	while (i < map->map_height)
	{
		while (j < map->map_length)
		{
			ft_image_to_win(map, map->map_data[i][j], j, i);
			j++;
		}
		j = 0;
		i++;
	}
	map->stepping = ft_itoa(map->steps);
	write(1, "STEP ", 5);
	write(1, map->stepping, ft_strlen(map->stepping));
	write(1, "\n", 1);
	map->steps++;
	mlx_string_put(map->mlx, map->win, 50, 50, -1, map->stepping);
	free(map->stepping);
}

int	ft_finish(t_game *map)
{
	write(2, "You win!\n", 9);
	ft_free_textures(map);
	exit(1);
	return (1);
}
