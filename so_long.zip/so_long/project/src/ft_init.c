/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/28 13:06:04 by pbronn            #+#    #+#             */
/*   Updated: 2022/06/02 11:19:01 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"
#include <stdio.h>

void	ft_err(char *s)
{
	int	len;

	len = ft_strlen(s);
	write(2, "Error!\n", 7);
	write(2, s, len);
	exit(2);
}

void	ft_null_type(t_game *s)
{
	s->map_height = 0;
	s->map_length = 0;
	s->player_position_x = -1;
	s->player_position_y = -1;
	s->pos_x = -1;
	s->pos_y = -1;
	s->pos = 1;
	s->game_score = 0;
	s->max_score = 0;
	s->steps = 0;
}

void	ft_count(t_game *game, int fd)
{
	int		tmp;
	int		buf;
	char	c;

	game->map_height = 0;
	game->map_length = 0;
	tmp = 0;
	buf = 0;
	while (read(fd, &c, 1) > 0)
	{
		if (game->map_length < tmp)
			game->map_length = tmp;
		if (c == '\n')
		{
			game->map_height++;
			tmp = 0;
		}
		else
			tmp++;
		if (tmp == 1)
			buf++;
	}
	if (buf > game->map_height)
		game->map_height = buf;
}

void	ft_null_str(t_game *game, int fd)
{
	int	i;

	ft_count(game, fd);
	close(fd);
	game->map_data = (char **)malloc(sizeof(char *) * (game->map_height));
	i = 0;
	while (i < game->map_height)
	{
		game->map_data[i] = (char *)malloc(sizeof(char) * (game->map_length));
		i++;
	}
}

int	ft_check_rect(char *line, int i, t_game *s)
{
	int	a;

	a = 0;
	if (line[0] != '1' || line[(s->map_length - 1)] != '1')
		return (0);
	if (i == 0 || i == ((s->map_height) - 1))
	{
		while (a < s->map_length)
		{
			if (line[a] != '1')
				return (0);
			a++;
		}
	}
	return (1);
}
