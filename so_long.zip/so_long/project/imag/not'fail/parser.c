/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/27 13:52:08 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/22 16:07:17 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./include/so_long.h"
#include <stdio.h>

// cc -L./mlx -lmlx -framework OpenGL -framework Appkit ft_check_type.c parser.c ft_strjoin.c get_next_line.c get_next_line_utils.c so_long.c ft_itoa.c
//  ------>y
// |
// |
// |
// V
// x

size_t	ft_strlen(const char *str)
{
	size_t	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

void ft_err(char *s)
{
	int len;

	len = ft_strlen(s);
	// ft_free_textures(map);
	write(2, "Error!\n", 7);
	write(2, s, len);
	exit(2);
}

void ft_null_type (t_game *s)
{
	s->map_height = 0;
	s->map_length = 0;
	s->player_position_x = -1;
	s->player_position_y = -1;
	s->game_score = 0;
	s->max_score = 0;
	s->steps = 0;
}

void	ft_count(t_game *game, int fd)
{
	int		tmp;
	char	c;

	game->map_height = 0;
	game->map_length = 0;
	tmp = 0;
	while (read(fd, &c, 1) > 0)
	{
		if (game->map_length < tmp)
			game->map_length = tmp;
		if (c == '\n')
		{
			game->map_height++;
			tmp = 0;
		}
		else
			tmp++;
	}
}

void ft_null_str(t_game *game, int fd)
{
	int	i;

	ft_count(game, fd);
	close(fd);
	game->map_data = (char **)malloc(sizeof(char *) * (game->map_height));
	i = 0;
	while (i < game->map_height)
	{
		game->map_data[i] = (char *)malloc(sizeof(char) * (game->map_length));
		i++;
	}
}

int ft_check_rect(char *line, int i, t_game *s)
{
	int		a;
	
	a = 0;
	if (line[0] != '1' || line[(s->map_length - 1)] != '1')
		return (0);
	if (i == 0 || i == ((s->map_height) - 1))
	{
		while (a < s->map_length)
			{
				if (line[a] != '1')
					return (0);
				a++;
			}
	}
	return (1);
}

int	ft_arr(char *line, t_game *s)
{
	int		i;
	int		a;
	
	i = 0;
	a = 1;
	while(line[i] && line[i] != '\n')
	{
		if (line[i] != '0' && line[i] != '1' && line[i] != 'C' && line[i] != 'E' && line[i] != 'P')
			return (0);
		if (line[i] == 'C')
			s->max_score++;
		if (line[i] == 'E')
			a = 2;
		if (line[i] == 'P' && s->player_position_x < 0)
			s->player_position_x = i;
		i++;
	}
	return (a);
}

void ft_completion_data(char *line, int i, t_game *s)
{
	int	j;
	
	j = 0;
	if (!ft_check_rect(line, i, s))
		ft_err("Invalid card!\n");
	while (j < s->map_length)
		{
			s->map_data[i][j] = line[j];
			j++;
		}
}

int ft_init_type(t_game *s, int fd)
{
	char	*line;
	int		a;
	int		e;
	int		i;
	
	i = 0;
	a = 1;
	e = 0;
	while(i >= 0 && a)
	{
		line = get_next_line(fd);
		if(!line)
			break ;
		a = ft_arr(line, s);
		if (a == 2)
			e = 1;
		if (s->player_position_x != -1 && s->player_position_y == -1)
			s->player_position_y = i;
		ft_completion_data(line, i, s);
		free(line);
		i++;
	}
	if (s->max_score == 0 || s->player_position_x == -1 || a*e == 0)
	 	ft_err("Invalid card!\n");
	return (i);
}
void ft_filling(char *filename, t_game *s)
{
	int	fd;

	fd = open_file(filename);
	ft_init_type(s, fd);
	close(fd);
}

int	main(int ac, char **av)
{
	t_game	stak;
	int		fd;

	if (ac == 2)
	{
		fd = ft_check_type(av[1]);
		ft_null_type(&stak);
		ft_null_str(&stak, fd);
		ft_filling(av[1], &stak);
		so_long(&stak);
	}
	else
		ft_err("No argument!\n");
	sleep(22222);
	return (1);
}