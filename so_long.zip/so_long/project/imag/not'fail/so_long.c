#include "./include/so_long.h"

void ft_textures(t_game *map)
{
	int pos[2];

	(map)->wall = mlx_xpm_file_to_image((map)->mlx, "./images/1.xpm", &pos[0], &pos[1]);
	(map)->exit = mlx_xpm_file_to_image((map)->mlx, "./images/E.xpm", &pos[0], &pos[1]);
	(map)->player = mlx_xpm_file_to_image((map)->mlx, "./images/P.xpm", &pos[0], &pos[1]);
	(map)->floor = mlx_xpm_file_to_image((map)->mlx, "./images/0.xpm", &pos[0], &pos[1]);
	(map)->items = mlx_xpm_file_to_image((map)->mlx, "./images/C.xpm", &pos[0], &pos[1]);
}

void ft_image_to_win(t_game *map, char t, int x, int y)
{
	x*=100;
	y*=100;
	if (t == 'P')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->player, x, y);
	if (t == '1')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->wall, x, y);
	if (t == 'C')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->items, x, y);
	if (t == 'E')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->exit, x, y);
	if (t == '0')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->floor, x, y);
}



void ft_free_textures(t_game *map)
{
	int		i;
	char	**str;

	i = 0;
	str = map->map_data;
	while (i < map->map_height)
	{
		free(str[i]);
		i++;
	}
	free(str);
}

void ft_rendering(t_game *map)
{
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (i < map->map_height)
	{
		while (j < map->map_length)
		{
			ft_image_to_win(map, map->map_data[i][j], j, i);
			j++;
		}
		j = 0;
		i++;
	}
	map->stepping = ft_itoa(map->steps);
	map->steps++;
	mlx_string_put(map->mlx, map->win, 25, 25, -1, map->stepping);
	free(map->stepping);
}

int ft_finish(t_game *map)
{
	write(2, "You win!\n", 9);
	ft_free_textures(map);
	exit(1);
	return (1);
}

int up_down(t_game *map, int a)
{
	if (map->map_data[map->player_position_x + a][map->player_position_y] == '1')
		return (0);
	if (map->map_data[map->player_position_x + a][map->player_position_y] == 'C')
		map->game_score++;
	if (map->map_data[map->player_position_x + a][map->player_position_y] == 'E' &&  map->game_score < map->max_score)
		return (0);
	if (map->map_data[map->player_position_x + a][map->player_position_y] == 'E' && map->game_score == map->max_score)
			return (ft_finish(map));
	map->map_data[map->player_position_x][map->player_position_y] = '0';
	map->map_data[map->player_position_x + a][map->player_position_y] = 'P';
	ft_rendering(map);
	map->player_position_x = map->player_position_x + a;
	return (0);
}

int left_right(t_game *map, int a)
{
	if (map->map_data[map->player_position_x][map->player_position_y + a] == '1')
		return (0);
	if (map->map_data[map->player_position_x][map->player_position_y + a] == 'C')
		map->game_score++;
	if (map->map_data[map->player_position_x][map->player_position_y + a] == 'E' && map->game_score < map->max_score)
		return (0);
	if (map->map_data[map->player_position_x][map->player_position_y + a] == 'E' && map->game_score == map->max_score)
		return (ft_finish(map));
	map->map_data[map->player_position_x][map->player_position_y] = '0';
	map->map_data[map->player_position_x][map->player_position_y + a] = 'P';
	map->player_position_y = map->player_position_y + a;
	ft_rendering(map);
	return (0);
}

int key_hook(int keycode, t_game *map)
{
	if (keycode == 53)
	{
		mlx_destroy_window(map->mlx, map->win);
		ft_free_textures(map);
		exit(0);
	}
	if (keycode == 1)
		return (up_down(map, 1));
	if (keycode == 13)
		return (up_down(map, -1));
	if (keycode == 2)
		return (left_right(map, 1));
	if (keycode == 0)
		return (left_right(map, -1));
	return (0);
}

int exit_hook(int keycode, t_game *map)
{
	(void) keycode;
	(void) map;
	exit(0);
}

int so_long(t_game *s)
{
	s->mlx = mlx_init();
	s->win = mlx_new_window(s->mlx, (s->map_length * 100), (s->map_height * 100), "so_long");
	ft_textures(s);
	ft_rendering(s);
	mlx_hook(s->win, 2, 0, key_hook, s);
	
	mlx_hook(s->win, 17, 0, exit_hook, s);
	mlx_loop(s->mlx);

	return (0);
}