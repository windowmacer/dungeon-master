/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hooock.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pbronn <pbronn@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 19:23:47 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/24 19:24:16 by pbronn           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	ft_finish(t_game *map)
{
	write(2, "You win!\n", 9);
	ft_free_textures(map);
	exit(1);
	return (1);
}

int	up_down(t_game *map, int a)
{
	int	x;
	int	y;

	x = map->player_position_x;
	y = map->player_position_y;
	if (map->map_data[x + a][y] == '1')
		return (0);
	if (map->map_data[x + a][y] == 'C')
		map->game_score++;
	if (map->map_data[x + a][y] == 'E' && map->game_score < map->max_score)
		return (0);
	if (map->map_data[x + a][y] == 'E' && map->game_score == map->max_score)
		return (ft_finish(map));
	map->map_data[map->player_position_x][map->player_position_y] = '0';
	map->map_data[map->player_position_x + a][map->player_position_y] = 'P';
	ft_rendering(map);
	map->player_position_x = map->player_position_x + a;
	return (0);
}

int	left_right(t_game *map, int a)
{
	int	x;
	int	y;

	x = map->player_position_x;
	y = map->player_position_y;
	if (map->map_data[x][y + a] == '1')
		return (0);
	if (map->map_data[x][y + a] == 'C')
		map->game_score++;
	if (map->map_data[x][y + a] == 'E' && map->game_score < map->max_score)
		return (0);
	if (map->map_data[x][y + a] == 'E' && map->game_score == map->max_score)
		return (ft_finish(map));
	map->map_data[map->player_position_x][map->player_position_y] = '0';
	map->map_data[map->player_position_x][map->player_position_y + a] = 'P';
	map->player_position_y = map->player_position_y + a;
	ft_rendering(map);
	return (0);
}
