/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 18:22:46 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/27 22:53:29 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	key_hook(int keycode, t_game *map)
{
	if (keycode == 53)
	{
		mlx_destroy_window(map->mlx, map->win);
		ft_free_textures(map);
		exit(0);
	}
	if (keycode == 1)
		return (up_down(map, 1));
	if (keycode == 13)
		return (up_down(map, -1));
	if (keycode == 2)
		return (left_right(map, 1));
	if (keycode == 0)
		return (left_right(map, -1));
	return (0);
}

int	exit_hook(int keycode, t_game *map)
{
	(void) keycode;
	(void) map;
	exit(0);
}

int	so_long(t_game *s)
{
	s->mlx = mlx_init();
	s->win = mlx_new_window(s->mlx, (s->map_length * 100), \
	(s->map_height * 100), "so_long");
	ft_textures(s);
	ft_rendering(s);
	mlx_hook(s->win, 2, 0, key_hook, s);
	mlx_hook(s->win, 17, 0, exit_hook, s);
	mlx_loop(s->mlx);
	return (0);
}
