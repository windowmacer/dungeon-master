/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_type.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 18:20:39 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/27 22:43:15 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	ft_check_ber(char *name, char *ber, int len)
{
	int		i;
	int		j;

	i = len - 4;
	j = 0;
	while (i < len)
	{
		if (name[i] != ber[j])
			return (0);
		j++;
		i++;
	}
	return (1);
}

int	open_file(char *filename)
{
	int	fd;

	fd = open(filename, O_RDONLY);
	if (fd <= 0)
		ft_err("Fail open file!\n");
	return (fd);
}

int	ft_check_type(char *name)
{
	int		fd;
	int		len;

	fd = open_file(name);
	len = ft_strlen(name);
	if (!ft_check_ber(name, ".ber", len))
		ft_err("File extension error!\n");
	return (fd);
}
