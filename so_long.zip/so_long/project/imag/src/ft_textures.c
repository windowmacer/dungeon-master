/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_textures.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 18:50:07 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/27 23:11:07 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

size_t	ft_strlen(const char *str)
{
	size_t	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

void	ft_textures(t_game *m)
{
	int	p[2];

	m->wall = mlx_xpm_file_to_image(m->mlx, "./images/1.xpm", &p[0], &p[1]);
	m->exit = mlx_xpm_file_to_image(m->mlx, "./images/E.xpm", &p[0], &p[1]);
	m->player = mlx_xpm_file_to_image(m->mlx, "./images/P.xpm", &p[0], &p[1]);
	m->floor = mlx_xpm_file_to_image(m->mlx, "./images/0.xpm", &p[0], &p[1]);
	m->items = mlx_xpm_file_to_image(m->mlx, "./images/C.xpm", &p[0], &p[1]);
}

void	ft_image_to_win(t_game *map, char t, int x, int y)
{
	x *= 100;
	y *= 100;
	if (t == 'P')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->player, x, y);
	if (t == '1')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->wall, x, y);
	if (t == 'C')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->items, x, y);
	if (t == 'E')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->exit, x, y);
	if (t == '0')
		mlx_put_image_to_window((map)->mlx, (map)->win, (map)->floor, x, y);
}

void	ft_free_textures(t_game *map)
{
	int		i;
	char	**str;

	i = 0;
	str = map->map_data;
	while (i < map->map_height)
	{
		free(str[i]);
		i++;
	}
	free(str);
}

void	ft_rendering(t_game *map)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < map->map_height)
	{
		while (j < map->map_length)
		{
			ft_image_to_win(map, map->map_data[i][j], j, i);
			j++;
		}
		j = 0;
		i++;
	}
	map->stepping = ft_itoa(map->steps);
	map->steps++;
	mlx_string_put(map->mlx, map->win, 25, 25, -1, map->stepping);
	free(map->stepping);
}
