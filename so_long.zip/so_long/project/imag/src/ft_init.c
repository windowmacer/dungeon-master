/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 18:35:44 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/27 22:47:43 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_err(char *s)
{
	int	len;

	len = ft_strlen(s);
	write(2, "Error!\n", 7);
	write(2, s, len);
	exit(2);
}

void	ft_null_type(t_game *s)
{
	s->map_height = 0;
	s->map_length = 0;
	s->player_position_x = -1;
	s->player_position_y = -1;
	s->game_score = 0;
	s->max_score = 0;
	s->steps = 0;
}

void	ft_count(t_game *game, int fd)
{
	int		tmp;
	char	c;

	game->map_height = 0;
	game->map_length = 0;
	tmp = 0;
	while (read(fd, &c, 1) > 0)
	{
		if (game->map_length < tmp)
			game->map_length = tmp;
		if (c == '\n')
		{
			game->map_height++;
			tmp = 0;
		}
		else
			tmp++;
	}
}

void	ft_null_str(t_game *game, int fd)
{
	int	i;

	ft_count(game, fd);
	close(fd);
	game->map_data = (char **)malloc(sizeof(char *) * (game->map_height));
	i = 0;
	while (i < game->map_height)
	{
		game->map_data[i] = (char *)malloc(sizeof(char) * (game->map_length));
		i++;
	}
}

int	ft_init_type(t_game *s, int fd)
{
	char	*line;
	int		a;
	int		e;
	int		i;

	i = 0;
	a = 1;
	e = 0;
	while (i >= 0 && a)
	{
		line = get_next_line(fd);
		if (!line)
			break ;
		a = ft_arr(line, s);
		if (a == 2)
			e = 1;
		if (s->player_position_x != -1 && s->player_position_y == -1)
			s->player_position_y = i;
		ft_completion_data(line, i, s);
		free(line);
		i++;
	}
	if (s->max_score == 0 || s->player_position_x == -1 || a * e == 0)
	{
		ft_free_textures(s);
		ft_err("Invalid card!\n");
	}
	return (i);
}
