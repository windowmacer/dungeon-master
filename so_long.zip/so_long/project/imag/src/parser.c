/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kirill <kirill@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/24 18:21:45 by pbronn            #+#    #+#             */
/*   Updated: 2022/05/27 22:48:30 by kirill           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"
#include <stdio.h>

int	ft_check_rect(char *line, int i, t_game *s)
{
	int		a;

	a = 0;
	if (line[0] != '1' || line[(s->map_length - 1)] != '1')
		return (0);
	if (i == 0 || i == ((s->map_height) - 1))
	{
		while (a < s->map_length)
		{
			if (line[a] != '1')
				return (0);
			a++;
		}
	}
	return (1);
}

int	ft_arr(char *line, t_game *s)
{
	int		i;
	int		a;

	i = 0;
	a = 1;
	while (line[i] && line[i] != '\n')
	{
		if (line[i] != '0' && line[i] != '1' && line[i] \
		!= 'C' && line[i] != 'E' && line[i] != 'P')
			return (0);
		if (line[i] == 'C')
			s->max_score++;
		if (line[i] == 'E')
			a = 2;
		if (line[i] == 'P' && s->player_position_x < 0)
			s->player_position_x = i;
		i++;
	}
	return (a);
}

void	ft_completion_data(char *line, int i, t_game *s)
{
	int	j;

	j = 0;
	if (!ft_check_rect(line, i, s))
	{
		ft_free_textures(s);
		ft_err("Invalid card!\n");
	}
	while (j < s->map_length)
	{
		s->map_data[i][j] = line[j];
		j++;
	}
}

void	ft_filling(char *filename, t_game *s)
{
	int	fd;

	fd = open_file(filename);
	ft_init_type(s, fd);
	close(fd);
}

int	main(int ac, char **av)
{
	t_game	stak;
	int		fd;

	if (ac == 2)
	{
		fd = ft_check_type(av[1]);
		ft_null_type(&stak);
		ft_null_str(&stak, fd);
		ft_filling(av[1], &stak);
		so_long(&stak);
	}
	else
		ft_err("No argument!\n");
	return (1);
}
